'use strict';

class AudioQueue {
  constructor(options, dispatchTarget, sounds) {
    this.options = options;
    this.dispatchTarget = dispatchTarget;
    this.sounds = sounds;

    this.queue = [];
  }

  next() {
    if (this.queue.length === 0) { return; }

    const first = this.queue[0];
    if (typeof first.play === 'function') {
      first.play().catch(error => {
        // Chrome does not allow autoplay of sounds when a page is loaded
        // and the user has not interacted with it yet.
        // Ignore these errors.
        if (error instanceof DOMException && error.name === 'NotAllowedError') { return; } // jshint ignore:line

        console.error('play() error', error, first, this.queue);
      });
    }
  }

  clear(keepFirst = false) {
    // Keep the first audio file if its playback has not finished and the game is over
    const first = this.queue[0];

    this.queue = keepFirst && first && !first.ended ? [first] : [];

    this.dispatchTarget.dispatchEvent(new CustomEvent('queueCleared'));
  }

  createQueueAudio(file) {
    let audio;

    const doEnded = () => {
      // Clear the queue if there are too many sounds queued to make sure the
      // commentator is not too far behind the game with his commentary
      if (this.queue.length > 30) {
        this.clear();
      } else {
        this.queue.shift();
        this.next();
      }
    };

    // Random error, sound not playing and queue building up (since it is
    // only cleared in the play() callback).
    // Making sure to clear it if it gets too large
    // @TODO: Figure out a better way
    if (this.queue.length > 30) {
      const duration = this.queue[0].duration;
      setTimeout(() => { this.clear(); }, duration * 1000); // Making sure sounds don't overlap
    }
    audio = AudioUtils.create(file, this.options.commentator, this.options.volume / 100);
    audio.addEventListener('ended', doEnded, false);

    return audio;
  }

  getPiece(piece){
    if(piece == "R"){
      return "rook"
    } else if (piece == "N"){
      return "knight"
    } else if (piece == "B"){
      return "bishop"
    } else if (piece == "Q"){
      return "queen"
    } else if (piece == "K"){
      return "king"
    } else if (piece == "x"){
      return "takes"
    }
    return piece
  }

  push(key) {
    if (typeof key === 'undefined') { return; }

    if(this.options.commentator == "michael"){
      console.log(key);
      if(key == 'check'){
        const audio = new Audio(browser.extension.getURL('ogg/michael/check.mp3'));
        audio.play();
      } else if (key == "fill" || key == "misc"){
        return;
      } else if (key.includes("O-O")){
        const audio = new Audio(browser.extension.getURL('ogg/michael/castle.mp3'));
        audio.play();
      } else if (key.length < 8){
        let audioPaths = key.split('');
        let currentAudioIndex = 0;
        function playNextAudio() {
          const getPiece = (piece) => ({ R: "rook", N: "knight", B: "bishop", Q: "queen", K: "king", x: "takes" }[piece] || piece);
          if (currentAudioIndex < audioPaths.length) {
            console.log(audioPaths,getPiece(audioPaths[currentAudioIndex]));
            const audio = new Audio(browser.extension.getURL('ogg/michael/'+getPiece(audioPaths[currentAudioIndex])+'.mp3'));
            audio.playbackRate = 1.8;
            audio.addEventListener("ended", playNextAudio);
            audio.play();
            currentAudioIndex++;
          }
        }
        playNextAudio();

        //
        // key.split('').forEach((char) => {
        //   const audio = new Audio(browser.extension.getURL('ogg/michael/'+this.getPiece(char)+'.mp3'));
        //
        //   const doEnded = () => {
        //     // Clear the queue if there are too many sounds queued to make sure the
        //     // commentator is not too far behind the game with his commentary
        //     if (this.queue.length > 30) {
        //       this.clear();
        //     } else {
        //       this.queue.shift();
        //       this.next();
        //     }
        //   };
        //   audio.addEventListener('ended', doEnded, false);
        //   audio.playbackRate = 2;
        //   this.queue.push(audio);
        //   console.log('this.queue.length:',this.queue.length);
        //   if (this.queue.length === 1) { this.next(); }
        // });
      } else if (key.includes("Checkmate")){
        const audio = new Audio(browser.extension.getURL('ogg/michael/checkmate.mp3'));
        audio.play();
      }
      return;

    }

    let file = AudioUtils.getRandom(this.sounds, key, this.options.commentator) || AudioUtils.getGeneric(this.sounds, key, this.options.commentator);

    console.log(file);

    // Random chance (1/6) to play a 'fill' sound instead of nothing
    // when there is no sound for the notation
    // const trueOneOutOfSix = () => !(Math.floor(Math.random() * 6));
    // if (!file && trueOneOutOfSix()) {
    //   file = AudioUtils.getRandom(this.sounds, 'fill', this.options.commentator);
    // }

    // If still no file to play, abort audio queue process
    if (!file) { return; }
    this.queue.push(this.createQueueAudio(file));

    if (this.queue.length === 1) { this.next(); }
  }
}
